package com.example.finalpractice;

import com.example.finalpractice.entity.Savings;
import com.example.finalpractice.repository.SavingsRepository;
import com.example.finalpractice.service.SavingsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;   // AssertJ
import static org.mockito.Mockito.*;                         // Mockito (includes verify)

@ExtendWith(MockitoExtension.class)
class SavingsServiceTester {

    @Mock
    private SavingsRepository savingsRepository;

    @InjectMocks
    private SavingsService savingsService;

    @Test
    void findAll_returnsListFromRepository() {
        when(savingsRepository.findAll()).thenReturn(List.of(new Savings()));

        var result = savingsService.findAll();

        assertThat(result).hasSize(1);
        verify(savingsRepository).findAll();
    }

    @Test
    void existsById_delegatesToRepository() {
        when(savingsRepository.existsById(101)).thenReturn(true);

        assertThat(savingsService.existsById(101)).isTrue();
        verify(savingsRepository).existsById(101);
    }

    @Test
    void save_callsRepositorySave() {
        Savings s = new Savings();
        s.setCustomerNumber(101);

        savingsService.save(s);

        verify(savingsRepository).save(s);
    }

    @Test
    void findById_returnsEntityFromRepository() {
        Savings s = new Savings();
        s.setCustomerNumber(123);
        when(savingsRepository.findById(123)).thenReturn(Optional.of(s));

        Savings result = (Savings) savingsService.findById(123);

        assertThat(result).isSameAs(s);
        verify(savingsRepository).findById(123);
    }

    @Test
    void delete_callsRepositoryDeleteById() {
        savingsService.delete(77);
        verify(savingsRepository).deleteById(77);
    }






}
