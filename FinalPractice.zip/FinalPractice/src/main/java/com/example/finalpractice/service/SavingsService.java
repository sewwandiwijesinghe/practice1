package com.example.finalpractice.service;

import com.example.finalpractice.entity.Savings;
import com.example.finalpractice.repository.SavingsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@Service
public class SavingsService {

    @Autowired
    private SavingsRepository savingsRepository;

    public List<Savings> findAll() {
        return savingsRepository.findAll();
    }




    public  void save(Savings savings) {

        savingsRepository.save(savings);
    }




    public boolean existsById(Integer customerNumber) {

        return savingsRepository.existsById(customerNumber);
    }



    public Object findById(int id) {

        return savingsRepository.findById(id).get();
    }


    public void delete(Integer id) {


        savingsRepository.deleteById(id);
    }
}
