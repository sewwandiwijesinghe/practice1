package com.example.finalpractice.controller;

import com.example.finalpractice.entity.Savings;
import com.example.finalpractice.repository.SavingsRepository;
import com.example.finalpractice.service.SavingsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class SavingsController {

    @Autowired
    private SavingsService savingsService;


    @GetMapping

    public String home(Model model) {
        model.addAttribute("savings", savingsService.findAll());
        return "index";


    }

    @GetMapping("/add")
    public String addToForm(Model model) {
        model.addAttribute("savings", new Savings());
        return "add";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute Savings savings, Model model) {
        if (savingsService.existsById(savings.getCustomerNumber())) {
            model.addAttribute("error", "Customer number already exists.");
            return "add";
        }
        savingsService.save(savings);
        return "redirect:/";
    }


@GetMapping("/edit/{id}")
    public String editForm(@PathVariable Integer id, Model model) {
        model.addAttribute("savings",savingsService.findById(id));
        return "edit";

    }


    @PostMapping("/edit")
    public String saveEdited(@ModelAttribute Savings savings) {
        savingsService.save(savings);
        return "redirect:/";
    }


@GetMapping("/delete/{id}")
    public String delete(@PathVariable Integer id) {
        savingsService.delete(id);
    return "redirect:/";
}


    @GetMapping("/projection/{id}")
    public String projection(@PathVariable int id, Model model) {
        Savings s = (Savings) savingsService.findById(id);


        if (s == null) {
            return "redirect:/";
        }


        List<Double> projections = new ArrayList<>();
        double amount = s.getInitialDeposit();
        double rate = s.getSavingsType().equalsIgnoreCase("De-luxe") ? 0.15 : 0.10;


        for (int year = 1; year <= s.getNumberOfYears(); year++) {
            amount += amount * rate;
            projections.add(amount);
        }


        model.addAttribute("savings", s);
        model.addAttribute("projections", projections);
        return "projection";
    }








}
